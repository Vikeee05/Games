# Ion Storm Pinball

A two-deck neon pinball game that runs in the browser. Version 5.

## Files

| Path | What it is |
|---|---|
| `ion-storm-pinball.html` | The whole game in one file. Open it in any browser, works offline. |
| `ios/` | iPhone Home Screen app version (web app with icon, full screen, offline play). |

## Play on a computer

Download `ion-storm-pinball.html` and double-click it.

Controls: `Z` / `←` left flipper, `/` / `→` right flipper, `Space` to pull the plunger (release to launch).

## Install on iPhone

1. Turn on GitHub Pages for this repository: **Settings → Pages → Deploy from a branch → main → / (root) → Save**.
2. Open the `ios/` folder's page in Safari:
   `https://<your-username>.github.io/<repo-name>/ion-storm/ios/`
3. Tap **Share → Add to Home Screen → Add**.
4. Open it once while online. After that it also works offline.

Touch controls: tap left side for the left flipper, tap right side for the right flipper, hold the right side to pull the plunger.

## Updating

After changing files in `ios/`, raise `VERSION` in `ios/sw.js` (currently `ion-storm-v5`) so installed phones refresh their offline copy.

## Features

- Upper and lower decks, with the ball falling freely from one into the other
- Combos, spinners, orbit shots, jackpot, mystery orb, bumper levels
- Lower deck: star lanes, Vault, moving Shuttle target, P·O·W·E·R lift back up
- Power-ups: Mega Ball, Shield, Slow-Mo, Frenzy, Overload, Multiball
- Table colors change at score milestones (250k, 1M, 2.5M, 5M, 10M)
